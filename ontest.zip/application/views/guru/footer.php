<!-- <div class="footer-copyright-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-copy-right">
                    <p>Copyright © 2020. rtn skrispi.</p>
                </div>
            </div>
        </div>
    </div>
</div> -->
    <script src="<?= base_url();?>/assets/jquery/jquery-3.3.1.js"></script>
    <script src="<?= base_url();?>/asset/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="<?= base_url();?>/asset/ckeditor/ckeditor.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/bootstrap.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/wow.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/jquery-price-slider.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/jquery.meanmenu.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/owl.carousel.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/jquery.sticky.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/jquery.scrollUp.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/scrollbar/mCustomScrollbar-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/bootstrap-table.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/tableExport.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/bootstrap-editable.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/data-table/bootstrap-table-export.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/counterup/waypoints.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/counterup/counterup-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/scrollbar/mCustomScrollbar-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/metisMenu/metisMenu-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/morrisjs/raphael-min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/morrisjs/morris.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/morrisjs/morris-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/sparkline/sparkline-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/calendar/moment.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/calendar/fullcalendar.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/calendar/fullcalendar-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/chart/jquery.peity.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/peity/peity-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/jquery.maskedinput.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/masking-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/datepicker/jquery-ui.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/datepicker/datepicker-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/datepicker/moment.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/datepicker/bootstrap-datetimepicker.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/form-validation/jquery.form.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/form-validation/jquery.validate.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/tab.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/plugins.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/main.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/chosen/chosen.jquery.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/chosen/chosen-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/select2/select2.full.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/select2/select2-active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/ionRangeSlider/ion.rangeSlider.min.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/ionRangeSlider/ion.rangeSlider.active.js"></script>
    <script src="<?= base_url();?>/asset/themee/js/input-mask/jasny-bootstrap.min.js"></script>
    <script src="<?= base_url();?>/asset/bootbox/bootbox.min.js"></script>
    <script src="<?= base_url();?>/asset/bootbox/bootbox.locales.min.js"></script>
    
</body>
</html>