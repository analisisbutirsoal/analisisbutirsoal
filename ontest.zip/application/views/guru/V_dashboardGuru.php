<div class="traffic-analysis-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="social-media-edu">
                    <i class="educate-icon educate-department"></i>
                    <div class="social-edu-ctn">
                        <h3>Kelas Yang Diampu</h3>
                        <h4><span class="counter"><?= $kelas?></span></h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="social-media-edu twitter-cl res-mg-t-30 table-mg-t-pro-n">
                    <i class="educate-icon educate-data-table"></i>
                    <div class="social-edu-ctn">
                        <h3>Ujian</h3>
                        <h4><span class="counter"><?= $ujian?></span></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>